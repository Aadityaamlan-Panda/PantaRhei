// Variables
console.log("JavaScript file loaded!");

const goalInput = document.getElementById("goal");
const deadlineInput = document.getElementById("deadline");
const bucketList = document.getElementById("bucket-list");
const timeSlotTableBody = document.getElementById("time-slot-table").querySelector("tbody");

let usableBucketList = [];

// Analyze Goal and Predict Tasks
document.getElementById("analyze-goal-btn").addEventListener("click", async () => {
    console.log("Analyze Goal button clicked!");
    const goal = goalInput.value;
    const deadline = deadlineInput.value;
    console.log("Goal:", goal, "Deadline:", deadline);


    if (!goal || !deadline) {
        alert("Please fill in both the goal and deadline.");
        return;
    }

    console.log("Sending request to /analyze_goal with:", { goal, deadline });
const response = await fetch("/analyze_goal", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ goal, deadline }),
});
console.log("Received response from /analyze_goal");


const data = await response.json();
console.log("Response Data:", data);

const verdictDiv = document.getElementById("verdict");
    verdictDiv.innerHTML = `<strong>Analysis Verdict:</strong><br>${data.verdict}`;
    usableBucketList = data.tasks;

    document.getElementById("verdict-section").style.display = "block";
    // Update bucket list on the screen
    updateBucketList();
});

// Add Additional Task
document.getElementById("add-task-btn").addEventListener("click", () => {
    const additionalTask = prompt("Enter an additional task:");
    if (additionalTask) {
        usableBucketList.push(additionalTask);
        updateBucketList();
    }
});

// Update Bucket List
function updateBucketList() {
    bucketList.innerHTML = "";
    usableBucketList.forEach((task) => {
        console.log("Adding task:", task)
        const listItem = document.createElement("li");
        listItem.textContent = task;
        bucketList.appendChild(listItem);
    });
}

// Populate 24-hour Time Slots
function populateTimeSlots() {
    for (let i = 0; i < 24; i++) { // Looping for 12 slots instead of 24 for 2-hour intervals
        const start = (i).toString().padStart(2, "0") + ":00";  // Start time
        const end = ((i + 1)).toString().padStart(2, "0") + ":00";  // End time

        const row = document.createElement("tr");

        const timeSlotCell = document.createElement("td");
        timeSlotCell.textContent = `${start} - ${end}`;
        row.appendChild(timeSlotCell);

        const activityCell = document.createElement("td");
        activityCell.textContent = "Unassigned";
        row.appendChild(activityCell);

        const actionCell = document.createElement("td");

        // Assign Task Button
        const assignButton = document.createElement("button");
        assignButton.textContent = "Assign Task";
        assignButton.addEventListener("click", () => assignTask(`${start} - ${end}`, activityCell));
        actionCell.appendChild(assignButton);

        // Meal Button
        const mealButton = document.createElement("button");
        mealButton.textContent = "Meal";
        mealButton.addEventListener("click", () => {
            activityCell.textContent = "Meal";
        });
        actionCell.appendChild(mealButton);

        // Sleep Button
        const sleepButton = document.createElement("button");
        sleepButton.textContent = "Sleep";
        sleepButton.addEventListener("click", () => {
            activityCell.textContent = "Sleep";
        });
        actionCell.appendChild(sleepButton);

        // Commit Elsewhere Button
        const commitElsewhereButton = document.createElement("button");
        commitElsewhereButton.textContent = "Commit Elsewhere";
        commitElsewhereButton.addEventListener("click", () => {
            activityCell.textContent = "Commit Elsewhere";
        });
        actionCell.appendChild(commitElsewhereButton);

        row.appendChild(actionCell);

        timeSlotTableBody.appendChild(row);
    }
}

// Assign Task to Time Slot
async function assignTask(timeSlot, activityCell) {
    try {
        const response = await fetch("/assign_task", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ time_slot: timeSlot, bucket_list: usableBucketList }),
        });

        if (!response.ok) {
            throw new Error(`Error: ${response.status}`);
        }

        const data = await response.json();

        // Check if ai_response exists
        if (data.ai_response) {
            // Display full AI response in a popup
            alert(`AI Suggestion for ${timeSlot}:\n\n${data.ai_response}`);
        } else {
            alert(`No response from AI for ${timeSlot}.`);
        }

        // Save the key task directly
        const keyTask = data.task_display || "Unassigned";
        activityCell.textContent = keyTask;
        task = data.task;
        if (task !== "Unassigned") {
            usableBucketList = usableBucketList.filter((t) => t !== task);
        }

    } catch (error) {
        alert(`An error occurred: ${error.message}`);
        console.error("Error assigning task:", error);
    }
}



// Save Schedule
document.getElementById("save-schedule-btn").addEventListener("click", async () => {
    const schedule = gatherSchedule();
    await fetch("/save_schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ schedule }),
    });
    alert("Schedule saved successfully!");
});

// Export Schedule as PDF
document.getElementById("export-pdf-btn").addEventListener("click", async () => {
    const schedule = gatherSchedule();
    await fetch("/export_pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ schedule }),
    });
    alert("PDF generated successfully!");
});

// Gather Schedule
function gatherSchedule() {
    const rows = timeSlotTableBody.querySelectorAll("tr");
    const schedule = {};

    rows.forEach((row) => {
        const timeSlot = row.children[0].textContent;
        const activity = row.children[1].textContent;
        schedule[timeSlot] = activity;
    });

    return schedule;
}

// Initialize
populateTimeSlots();
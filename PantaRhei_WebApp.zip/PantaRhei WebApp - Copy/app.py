from flask import Flask, request, jsonify, render_template
import json
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from reportlab.lib import colors
from reportlab.platypus import Paragraph
from reportlab.lib.styles import getSampleStyleSheet
import cohere

app = Flask(__name__)

# Cohere API setup
api_key = " "  # Replace with your Cohere API key
co = cohere.Client(api_key)

# Route: Home Page
@app.route('/')
def index():
    return render_template('index.html')  # Serve the HTML page

# Route: Analyze Goal
@app.route('/analyze_goal', methods=['POST'])
def analyze_goal():
    data = request.json
    print("Received data:", data)  # Debugging log
    goal = data.get("goal")
    deadline = data.get("deadline")
    print("Goal:", goal, "Deadline:", deadline)  # Debugging log

    # Call AI for analysis
    # Step 1: Generate goal analysis
    prompt = f"Analyze the goal: '{goal}' with a deadline of {deadline}. Suggest if it's realistic and predict tasks."
    response = co.generate(model="command-xlarge-nightly", prompt=prompt, max_tokens=300, temperature=0.7)
    ai_response = response.generations[0].text.strip()

    print("AI Response:", ai_response)

# Step 2: Extract tasks from the AI response
# Now, we'll tell the AI to extract only the tasks in a specific format
    extraction_prompt = f"""
The following is an analysis of a goal:

{ai_response}

Please extract ONLY the tasks from the response and list them one per line, with no extra information or explanation. Just the tasks, in a simple list format.
"""

# Send the extraction prompt to the AI
    response = co.generate(model="command-xlarge-nightly", prompt=extraction_prompt, max_tokens=300, temperature=0.7)

# Extract tasks from the generated text
    tasks = response.generations[0].text.strip().split("\n")

# Filter out any empty strings if any exist
    tasks = [task for task in tasks if task.strip() != ""]
  
    print("Extracted Tasks:", tasks)

# Return tasks as a JSON response
    return jsonify({
    "verdict": ai_response.replace("\n", "<br>").replace(" - ", "<br>• "),  # Replace newlines and bullets with HTML-friendly formatting
    "tasks": tasks
})


# Route: Assign Task
@app.route('/assign_task', methods=['POST'])
def assign_task():
    data = request.json
    time_slot = data.get("time_slot")
    bucket_list = data.get("bucket_list")

    # Call AI for task assignment
    prompt = f"Assign the best task for the time slot '{time_slot}' based on this bucket list: {bucket_list}"
    response = co.generate(model="command-xlarge-nightly", prompt=prompt, max_tokens=300, temperature=0.7)
    ai_response = response.generations[0].text.strip()

    # Second AI prompt to extract the main task
    extraction_prompt = f"""
    The following is an AI response suggesting a task for a specific time slot:

    {ai_response}

    From the provided response, extract the main key heading or task that best represents the suggestion. 
    If no clear key heading is found, respond with "Unassigned".
    """
    extraction_response = co.generate(model="command-xlarge-nightly", prompt=extraction_prompt, max_tokens=100, temperature=0.7)
    extracted_task = extraction_response.generations[0].text.strip()

    task_identification_prompt = f"""
    Based on the following task suggestion, return the **exact task** from the bucket list that matches the AI's suggestion.

    Suggested task by AI:

    {ai_response}

    Bucket list of tasks:

    {bucket_list}

    Return the exact task from the bucket list. If no task matches, return "Unassigned".
    """
    task_identification_response = co.generate(model="command-xlarge-nightly", prompt=task_identification_prompt, max_tokens=100, temperature=0.7)
    
# Extract the task from the response
    task_from_response = task_identification_response.generations[0].text.strip()


    # Return the full AI response for display and the extracted task for saving
    return jsonify({"ai_response": ai_response, "task_display": extracted_task, "task": task_from_response})


# Route: Save Schedule as JSON
@app.route('/save_schedule', methods=['POST'])
def save_schedule():
    schedule = request.json.get("schedule")
    with open("schedule.json", "w") as f:
        json.dump(schedule, f)
    return jsonify({"message": "Schedule saved successfully"})



@app.route('/export_pdf', methods=['POST'])
def export_pdf():
    schedule = request.json.get("schedule")
    filename = "schedule.pdf"

    # Define the PDF document
    pdf = SimpleDocTemplate(
        filename,
        pagesize=letter,  # Use landscape(letter) for horizontal layout if needed
        rightMargin=20,
        leftMargin=20,
        topMargin=30,
        bottomMargin=30
    )

    # Styles for wrapping content
    styles = getSampleStyleSheet()
    normal_style = styles["Normal"]

    # Prepare table data with wrapped text
    table_data = [["Time Slot", "Task"]]
    for slot, task in schedule.items():
        wrapped_task = Paragraph(task.replace("\n", "<br />"), normal_style)
        table_data.append([slot, wrapped_task])

    # Create and style the table
    table = Table(table_data, colWidths=[100, 400])  # Adjust colWidths as needed
    style = TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('VALIGN', (0, 0), (-1, -1), 'TOP')  # Align text at the top of cells
    ])
    table.setStyle(style)

    # Build the PDF
    pdf.build([table])

    return jsonify({"message": "PDF generated successfully", "filename": filename})



if __name__ == "__main__":
    app.run(debug=True)
